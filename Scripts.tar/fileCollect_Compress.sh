#!/bin/bash
#This scripts collect Log Files/Web Server Contents on a daily basis & creates a compressed file.
#Then uploads it to the S3 Bucket
#If the S3 bucket upload fails, a email is sent to TTO App Support Team

#Email Function
sendemail()
{
SUBJECT="S3 Bucket Upload Failure";
SENDGRID_API_KEY="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"
EMAIL_TO="julianaws2021@gmail.com"
FROM_EMAIL="julianwds82@gmail.com"
FROM_NAME="LSEG App Support"
MESSAGE="Upload to the S3 Bucket Failed. Please check imediately";

REQUEST_DATA='{"personalizations": [{
                   "to": [{ "email": "'"$EMAIL_TO"'" }],
                   "subject": "'"$SUBJECT"'"
                }],
                "from": {
                    "email": "'"$FROM_EMAIL"'",
                    "name": "'"$FROM_NAME"'"
                },
                "content": [{
                    "type": "text/plain",
                    "value": "'"$MESSAGE"'"
                }]
}';

curl -X "POST" "https://api.sendgrid.com/v3/mail/send" \
    -H "Authorization: Bearer $SENDGRID_API_KEY" \
    -H "Content-Type: application/json" \
    -d "$REQUEST_DATA"


}

#Defining the date/time
today=$(date +"%d_%m_%Y_%H.%M.%S")

#Compression activities
sudo tar -cvf /home/ec2-user/logs.tar /var/log/httpd
sudo tar -cvf /home/ec2-user/webServerContent.tar  /var/www/html/*
tar -czvf Logs_WebServerContents_${today}.tar.gz logs.tar webServerContent.tar

#Uploadning to the S3 Bucket
aws s3 cp *.tar.gz s3://julianbuck

#Hadles the upload failure part
code=$?
if [ $code == 0 ]
  then
   rm -f *.tar.gz *.tar
  else
   sendemail
fi
exit
