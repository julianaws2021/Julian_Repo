#!/bin/bash
#This Scrip will perform the below tasks
#  1.Will check if the WebServer is running & if not will start it



##list the service you want to check

insertvalue()
{
DB_USER='admin';
DB_PASSWD='#Domainprep1';
DB_HOST='juliandbinstance.cecfj2tgctb3.us-east-2.rds.amazonaws.com';
DB_NAME='appsuport';
TABLE='appsuporttbl';
timestamp=$(date '+%Y-%m-%d %H:%M:%S')
query="INSERT INTO $TABLE (id,msg,date) VALUES ('NULL','$1', '$timestamp')"
mysql -u$DB_USER -p$DB_PASSWD  -h$DB_HOST $DB_NAME -e "$query"


}

sendemail ()
{
SENDGRID_API_KEY="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"
EMAIL_TO="julianaws2021@gmail.com"
FROM_EMAIL="julianwds82@gmail.com"
FROM_NAME="LSEG App Support"

REQUEST_DATA='{"personalizations": [{
                   "to": [{ "email": "'"$EMAIL_TO"'" }],
                   "subject": "'"$1"'"
                }],
                "from": {
                    "email": "'"$FROM_EMAIL"'",
                    "name": "'"$FROM_NAME"'"
                },
                "content": [{
                    "type": "text/plain",
                    "value": "'"$2"'"
                }]
}';

curl -X "POST" "https://api.sendgrid.com/v3/mail/send" \
    -H "Authorization: Bearer $SENDGRID_API_KEY" \
    -H "Content-Type: application/json" \
    -d "$REQUEST_DATA"


}

	if ! pidof httpd > /dev/null
	then
		# web server down, restart the server
		sendemail "Apache Web Server is down" "Your Apache Web Server Service is down"
		insertvalue "Apache Web Server is down"
		echo "Apache Web Server is down"
		sudo systemctl start httpd

		if pidof httpd > /dev/null
		  then
			 msg="Apache restarted successfully"
			 sudo systemctl restart httpd
		  else
			  msg="Restart failed try restart mannually"
		fi
		sendemail "Web service" "$msg"
	fi

	if wget --spider -S "http://3.15.10.249/" 2>&1 | grep -w "200\|301" ; then
		echo "The Test Web Site is up"
		insertvalue "The Test Web Site is up"
		sendemail "The Test Web Site is up" "The Test Web Site is up & running as expected"
	else
		echo "The Test Web Site is down"
		insertvalue "The Test Web Site is down"
		sendemail "The Test Web Site is down" "The Test Web Site is down & not functioning as expected"
	fi

